package ca.qc.bdeb.sim203.tp2;

import javafx.scene.paint.Color;

public class ParticuleMagique extends BouleMagique{

    public ParticuleMagique(double xParticule,double yParticule,double vy, Color color) {
        super(xParticule, yParticule);
        //this.color=ImageHelper.ImageHelpers.couleurAuHasard();
        this.rayon=5;
        this.x=xParticule-rayon;
        this.y=yParticule-rayon;
        this.ay=0;
        this.vy=vy;
        this.ax=0;

    }
    public void update(double dt) {
        raffraichirPhysique(dt);


    }
}

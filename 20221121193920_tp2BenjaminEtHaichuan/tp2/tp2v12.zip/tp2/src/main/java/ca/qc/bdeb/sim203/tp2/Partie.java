package ca.qc.bdeb.sim203.tp2;

import javafx.application.Platform;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

import javax.net.ssl.SSLContextSpi;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Partie {
    protected int nbVies=3;
    protected boolean partieFinie=false;
    protected int score = 0;
    protected int niveau=1;
    protected Squelette squelette;
    protected ArrayList<MonstreNormal> tabMonstre=new ArrayList<>();
    protected MonstreNormal m1;
    double tempsBouleMagique=0;
    protected ArrayList<BouleMagique> b1=new ArrayList<>();
    protected double tempsEcouleDepuisDernierMonstre=0;
    protected double tempsEcouleDepuisDernierMonstreSpecial=0;

    public Partie() {
    }
    public void commencerPartie(){
        squelette= new Squelette();

    }


    public void eliminerMonstre (BouleMagique magie){
        ArrayList<MonstreNormal> tabAEnlever=new ArrayList<>();
        for (MonstreNormal monstre: tabMonstre){
            if (contactAvecMonstre(magie, monstre, magie.rayon, monstre.diametre/2)){
                score += 1;
                tabAEnlever.add(monstre);
            }
        }
        for(MonstreNormal monstre: tabAEnlever){
            tabMonstre.remove(monstre);
        }
    }

    public void deroulementPartie(double tempsEcoule){
        ArrayList<MonstreNormal> tabAEnlever=new ArrayList<>();
        for (MonstreNormal monstre: tabMonstre){
            if (monstre.horsDeEcran){
                tabAEnlever.add(monstre);
                nbVies -= 1;
            }
        }
        for(MonstreNormal monstre: tabAEnlever){
            tabMonstre.remove(monstre);
        }


        if ((int) tempsEcoule%3==0&&tempsEcoule-tempsEcouleDepuisDernierMonstre>=3){
            tabMonstre.add(new MonstreNormal(niveau));
            tempsEcouleDepuisDernierMonstre=tempsEcoule;
        }


        if ((int) tempsEcoule%5==0 && niveau>1&&tempsEcoule-tempsEcouleDepuisDernierMonstreSpecial>=5){
            creerMonstreSpecial();
            tempsEcouleDepuisDernierMonstreSpecial=tempsEcoule;
        }

        if (nbVies == 0){
            partieFinie = true;
        }

        //Pour l'instant je fait ca puisque je suis bloquer sur comment faire pour chaque valeur de 5
        switch (score){
            case 0 -> niveau = 1;
            case 5 -> niveau = 2;
            case 10 -> niveau = 3;
            case 15 -> niveau = 4;
            case 20 -> niveau = 5;
            case 25 -> niveau = 6;
            case 30 -> niveau = 7;
            case 35 -> niveau = 8;
            case 40 -> niveau = 9;
            case 45 -> niveau = 10;
        }
    }

    public void creerBouleMagique(double tempsEcoule){
        if(tempsEcoule-tempsBouleMagique>=0.6){
            b1.add(new BouleMagique(squelette.x, squelette.y)) ;
            tempsBouleMagique=tempsEcoule;
        }
    }
    public void creerMonstreSpecial(){
        if (Math.random()<0.5){
            tabMonstre.add(new MonstreOeil(niveau));
            System.out.println("123123124124");
        }
        else {
            tabMonstre.add(new MonstreBouche(niveau));
            System.out.println("123123124124");
        }
    }
    public boolean contactAvecMonstre(ObjetJeu magie, MonstreNormal monstre, int rayon1, int rayon2) {
        double dx = Math.abs(magie.x - monstre.x);
        double dy = Math.abs(magie.y - monstre.y);
        return dx + dy < (rayon1 + rayon2);
    }

    public void afficherNiveau(GraphicsContext context){
        context.setFill(Color.WHITE);
        context.setFont(new Font(45));

        context.setTextAlign(TextAlignment.CENTER);
        context.fillText("Niveau " + niveau, 320, 250);
    }

}

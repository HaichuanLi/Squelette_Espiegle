package ca.qc.bdeb.sim203.tp2;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.paint.Color;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.awt.*;

public class Main extends Application {

    private Stage stage;
    public static final double WIDTH = 640, HEIGHT = 480;
    private double tempsEcoule = 0;
    private double tempsEcouleAffichageNiveau = 0;
    Image vie = ImageHelper.ImageHelpers.colorize(
            new Image("squelette.png", 30, 30, true, false), Color.PINK);


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        this.stage = primaryStage;


        stage.setTitle("Squelette Espegiele");
        stage.setScene(sceneAccueil());
        stage.show();
    }

    private Scene sceneAccueil() {
        var root = new VBox();
        root.setStyle("-fx-background-color: black;");
        root.setSpacing(10);
        Scene sceneAcceuil = new Scene(root, WIDTH, HEIGHT);
        Image imgLogo = new Image("logo.png");

        ImageView logo = new ImageView(imgLogo);
        logo.setFitWidth(480);
        logo.setPreserveRatio(true);


        root.setAlignment(Pos.CENTER);
        var btnJouer = new Button("Jouer!");
        btnJouer.setOnAction((e) -> {
            stage.setScene(sceneJouer());
        });

        var btnInfo = new Button("Infos");
        btnInfo.setOnAction((e) -> {
            stage.setScene(sceneInfos());
        });
        root.getChildren().addAll(logo, btnJouer, btnInfo);

        return sceneAcceuil;


    }

    private Scene sceneJouer() {
        var pane = new StackPane();
        var sceneJeu = new Scene(pane, WIDTH, HEIGHT);
        var canvas = new Canvas(WIDTH, HEIGHT);
        var context = canvas.getGraphicsContext2D();

        Partie partie = new Partie();
        partie.commencerPartie();



        pane.setStyle("-fx-background-color: black;");
        var timer = new AnimationTimer() {
            long lastTime = System.nanoTime();
            double derniereValeurX;
            int niveauDeltaTempsPasse = 1;
            final double frameRate = 10 * 1e-9;
            @Override
            public void handle(long now) {
                context.clearRect(0, 0, WIDTH, HEIGHT);
                partie.deroulementPartie(tempsEcoule);
                if (niveauDeltaTempsPasse < partie.niveau){
                    tempsEcouleAffichageNiveau = 0;
                }
                dessinerInterface(context, partie);
                niveauDeltaTempsPasse = partie.niveau;

                double deltaTime = (now - lastTime) * 1e-9;
                double tempsEcouleSqueltte = deltaTime + lastTime;

                int frame = (int) Math.floor(tempsEcouleSqueltte * frameRate);
                Image imgMouvement = partie.squelette.getFrames()[frame%partie.squelette.getFrames().length];
                if (derniereValeurX == partie.squelette.x) {
                    partie.squelette.draw(context, partie.squelette.image);
                }
                else {
                    partie.squelette.draw(context, imgMouvement);
                }
                derniereValeurX = partie.squelette.x;
                partie.squelette.update(deltaTime);


                if (!partie.tabMonstre.isEmpty()) {
                    for (MonstreNormal monstre : partie.tabMonstre) {
                        context.drawImage(monstre.image, monstre.x, monstre.y);
                        monstre.update(deltaTime, tempsEcoule);
                       // System.out.println(monstre.horsDeEcran);


                    }
                }

                for (BouleMagique bouleMagique : partie.b1) {
                    partie.eliminerMonstre(bouleMagique);
                    if (bouleMagique.y + bouleMagique.diametre <= 0) {
                        partie.b1.remove(bouleMagique);
                        break;
                    }
                    context.setFill(Color.RED);
                    bouleMagique.update(deltaTime);
                    bouleMagique.tabParticuleCirconference.clear();
                    bouleMagique.creerParticuleCirconference();
                    context.fillOval(bouleMagique.x, bouleMagique.y, bouleMagique.diametre, bouleMagique.diametre);


                    for (ParticuleMagique particule : bouleMagique.tabParticuleCirconference) {
                        context.setFill(bouleMagique.color);
                        context.fillOval(bouleMagique.x + bouleMagique.rayon + particule.x, bouleMagique.y + bouleMagique.rayon + particule.y,
                                particule.rayon * 2, particule.rayon * 2);

                    }


                }
                
                tempsEcoule += deltaTime;
                tempsEcouleAffichageNiveau += deltaTime;
                lastTime = now;

                if(partie.partieFinie){

                    context.setFill(Color.RED);
                    context.setFont(new Font(45));

                    context.setTextAlign(TextAlignment.CENTER);
                    context.fillText("Game Over", 320, 250);
                }
            }

        };


        pane.getChildren().add(canvas);


        timer.start();


        sceneJeu.setOnKeyPressed((e) -> {
            if (e.getCode() == KeyCode.SPACE) {
                partie.creerBouleMagique(tempsEcoule);

            } else {
                Input.setKeyPressed(e.getCode(), true);
                System.out.println(e.getCode());
            }

        });
        sceneJeu.setOnKeyReleased((e) -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                Platform.exit();
            } else {
                Input.setKeyPressed(e.getCode(), false);
            }
        });



        return sceneJeu;
    }

    private void dessinerInterface(GraphicsContext context, Partie partie) {
        context.fillText(String.valueOf(partie.score), 320, 50);


        if (partie.nbVies > 0) {
            context.drawImage(vie, 265, 100);
        }
        if (partie.nbVies > 1) {
            context.drawImage(vie, 305, 100);
        }
        if (partie.nbVies > 2) {
            context.drawImage(vie, 345, 100);
        }

        if (tempsEcouleAffichageNiveau <= 3) {
            partie.afficherNiveau(context);
        }
    }

    private Scene sceneInfos() {
        var root = new VBox();
        Scene sceneInfos = new Scene(root, WIDTH, HEIGHT);
        var titre = new Text("Squelette Espiègle");
        titre.setFont(Font.font(38));

        var textHaichuan = new HBox();
        var textePar = new Text("Par");
        var nomColore1 = new Text("Haichuan Li");
        nomColore1.setFill(ImageHelper.ImageHelpers.couleurAuHasard());
        textePar.setFont(Font.font(20));
        nomColore1.setFont(Font.font(24));
        textHaichuan.getChildren().addAll(textePar, nomColore1);
        textHaichuan.setAlignment(Pos.CENTER);
        textHaichuan.setSpacing(5);

        var textBenjamin = new HBox();
        var texteEt = new Text("et");
        var nomColore2 = new Text("Benjamin Gurlekian");
        nomColore2.setFill(ImageHelper.ImageHelpers.couleurAuHasard());
        texteEt.setFont(Font.font(20));
        nomColore2.setFont(Font.font(24));
        textBenjamin.getChildren().addAll(texteEt, nomColore2);
        textBenjamin.setAlignment(Pos.CENTER);
        textBenjamin.setSpacing(5);

        var btnRetour = new Button("Retour");
        btnRetour.setOnAction((event -> {
            stage.setScene(sceneAccueil());
        }));
        root.getChildren().addAll(titre, textHaichuan, textBenjamin, btnRetour);
        root.setAlignment(Pos.CENTER);

        sceneInfos.setOnKeyPressed((event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                stage.setScene(sceneAccueil());
            }
        }));


        return sceneInfos;
    }


}

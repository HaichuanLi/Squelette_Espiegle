package ca.qc.bdeb.sim203.tp2;


import java.util.ArrayList;

public class BouleMagique extends Squelette {
    protected int rayon;
    protected int diametre;
    protected ArrayList<ParticuleMagique> tabParticuleCirconference = new ArrayList<>();


    public BouleMagique(double posSqueletteX, double posSqueletteY) {
        this.color=ImageHelper.ImageHelpers.couleurAuHasard();
        this.rayon = 35;
        this.diametre = 2 * rayon;
        this.vx = 0;
        this.vy = -300;
        this.ay = 0;
        this.ax = 0;
        this.x = posSqueletteX;
        this.y = posSqueletteY;


    }

    public void creerParticuleCirconference() {

        double xParticule, yParticule;
        double angle;
        for (int i = 0; i < 1; i++) {
            angle = (2 * Math.PI) / 100 * (    i+  1);
            xParticule = Math.cos(angle) * this.rayon;
            yParticule = Math.sin(angle) * this.rayon;
            tabParticuleCirconference.add(new ParticuleMagique(xParticule, yParticule,vy,color));
        }

    }

    public void update(double dt) {
        raffraichirPhysique(dt);
    }
}
